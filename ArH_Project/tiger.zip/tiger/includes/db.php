<?php
$host='localhost';
$user='root';
$password='';
$db='tiger';

$conn=mysqli_connect($host,$user,$password,$db);
 ?>
